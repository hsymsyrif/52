# WebGIS berbasis LeafletJS
Test Access? 

## DONE
Cek <a href="https://rifkifau.github.io/webgis-leaflet">kesini</a> coba

## Project Screenshot
![webgis dengan qgis2leaf](https://user-images.githubusercontent.com/24805357/35444840-5c9b2500-02e2-11e8-8f3f-901bd5d39e73.jpg)

## About
Dibuat dengan bantuan plugin QGIS2Leaf. Plugin keren tapi sekarang sudah tidak dikembangkan lagi. Sebagai gantinya ada plugin QGIS2Web. Kalau mau menjajal plugin ini, silakan sedot materialnya <a href="https://github.com/rifkifau/qgis2leaf">di sini</a> (Sumber library Geocoder sudah di update dan library leaflet sudah forced ke HTTPS). Tapi kalau mau ambil dari repository aslinya ya monggo, linknya di search aja. Bingung cara installnya, aku sarankan baca dulu <a href="https://spasialkan.com/2017/08/11/cara-membuat-webgis-plugin-qgis2leaf-leafletjs-quantumgis/">tutorialnya</a>.
